from .FastCNER import FastCNER
from .IOUtils import IOUtils, Rule, Span
__version__ = '1.0.10'
